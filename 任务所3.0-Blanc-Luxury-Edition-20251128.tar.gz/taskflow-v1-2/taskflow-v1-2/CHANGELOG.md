# 📝 Changelog - 任务所·Flow

所有重要变更都会记录在此文件中。

---

## [v1.7.0-alpha] - 2025-11-18

### 🏗️ 架构重构

#### Added
- ✅ **Monorepo结构** - 完整的企业级目录架构
  - `apps/` - 应用层（api, dashboard, worker）
  - `packages/` - 共享包（core-domain, infra, algorithms等）
  - `docs/` - 文档中心（arch, adr, api, ops-runbook）
  - `ops/` - 运维部署配置
  - `knowledge/` - 结构化知识库
  - `database/` - 数据库管理（schemas, migrations, seeds）
  - `tests/` - 测试目录
  - `config/` - 根配置

- ✅ **知识库数据库** - 9个新表
  - `projects` - 项目管理
  - `components` - 组件管理
  - `issues` - 问题追踪
  - `solutions` - 解决方案库
  - `decisions` - 技术决策（ADR数据库化）
  - `knowledge_articles` - 知识文章
  - `tools` - 工具管理
  - `component_tools` - 组件工具关联
  - `deployments` - 部署记录

- ✅ **数据库扩展**
  - tasks表添加 `project_id` 字段
  - tasks表添加 `component_id` 字段
  - 完整的索引策略

- ✅ **迁移工具** - database/migrations/migrate.py
  - 支持数据库初始化
  - 支持数据备份
  - 支持状态查询
  - 幂等性设计

- ✅ **默认数据**
  - 1个项目（任务所·Flow）
  - 5个组件（API/Dashboard/Domain/Infra/Algorithms）
  - 5个工具（FastAPI/Uvicorn/SQLite/Claude/PyYAML）
  - 5个组件工具关联

#### Changed
- 架构从单体改为Monorepo
- 数据库从3表扩展到12表

#### Status
- ✅ Phase 1: Monorepo骨架 - 100%完成
- ✅ Phase 2: 知识库Schema - 100%完成
- ⏳ Phase 3: 代码迁移 - 待开始
- ⏳ Phase 4-7: API扩展和测试 - 待开始

---

## [v1.6.0] - 2025-11-18

### 🔧 Bug修复

#### Fixed
- ✅ **Tab切换功能完全修复** - 解决JavaScript语法错误
  - 修复 templates.py 第4361行: Commit message格式反引号转义
  - 修复 templates.py 第4363行: 示例代码反引号转义
  - 修复 templates.py 第4378行: 文档路径反引号转义
  - 修复 templates.py 第4379行: API文档反引号转义

#### Root Cause
- JavaScript模板字符串内部反引号未转义
- 在Python f-string中导致语法错误
- 整个script标签失效

#### Added
- ✅ **恢复机制** - 恢复到v1.6.bat脚本
- ✅ **调试工具** - 5个调试脚本
- ✅ **完整文档** - 功能说明（1282行）

#### Status
- ✅ Tab切换100%正常
- ✅ 所有模块Tab工作
- ✅ JavaScript语法正确
- ✅ 生产就绪

---

## [v1.5.0] - 2025-11-18

### 🚀 独立发布

#### Added
- ✅ **独立封装** - 完整的可复用包
- ✅ **GitHub发布** - eva-wanxin-git/taskflow-v1.5
- ✅ **完整文档** - README, VERSION, 使用指南等7份文档
- ✅ **快捷脚本** - 启动任务所.bat

#### Features
- ✅ 实时Dashboard监控
- ✅ 任务状态管理
- ✅ 依赖分析引擎
- ✅ 任务调度系统
- ✅ 黑白红UI设计
- ✅ AI自动化支持（可选）

#### Status
- ✅ 37个文件
- ✅ 9,700+行代码
- ✅ 生产就绪
- ✅ GitHub公开

---

## [v1.0.0] - 2025-11-17

### 🎉 首次发布

#### Added
- ✅ 基础Dashboard功能
- ✅ 任务管理系统
- ✅ 版本切换系统
- ✅ 黑白红UI设计
- ✅ AI自动化框架

#### Status
- ✅ 核心功能完整
- ✅ 本地可用
- ✅ 备份保存

---

## 🎯 版本对比

| 特性 | v1.0 | v1.5 | v1.6 | v1.7 |
|------|------|------|------|------|
| Dashboard | ✅ | ✅ | ✅ | ⏳ |
| Tab切换 | ✅ | ✅ | ✅ 修复 | ⏳ |
| 任务管理 | ✅ | ✅ | ✅ | ⏳ |
| GitHub发布 | ❌ | ✅ | ❌ | ⏳ |
| 恢复机制 | ❌ | ❌ | ✅ | ⏳ |
| Monorepo | ❌ | ❌ | ❌ | ✅ |
| 知识库DB | ❌ | ❌ | ❌ | ✅ |
| 项目管理 | ❌ | ❌ | ❌ | ✅ |
| 组件管理 | ❌ | ❌ | ❌ | ✅ |
| 问题追踪 | ❌ | ❌ | ❌ | ✅ |

---

## 📞 版本链接

- **v1.5**: https://github.com/eva-wanxin-git/taskflow-v1.5
- **v1.6**: `../任务所-v1.6-Tab修复版/`
- **v1.7**: 当前仓库

---

**更新时间**: 2025-11-18  
**当前版本**: v1.7.0-alpha  
**状态**: Phase 1&2 完成

🎊 **持续进化，不断突破！**

