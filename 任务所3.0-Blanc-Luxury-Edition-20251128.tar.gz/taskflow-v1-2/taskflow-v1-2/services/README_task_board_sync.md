# 任务看板自动同步系统

## 📋 概述

自动化看板刷新系统，定期从事件流和数据库拉取最新状态，自动更新 `docs/tasks/task-board.md`。

## 🎯 功能特性

### 核心功能

1. **事件流监听**
   - 监听 `task.created`、`task.completed`、`task.status_changed` 事件
   - 从全局事件流获取任务状态变更

2. **数据库同步**
   - 从 SQLite 数据库查询任务最新状态
   - 支持多维度查询（状态、优先级、执行人等）

3. **智能对比**
   - 对比看板内容和数据库实际状态
   - 检测不一致并生成详细报告

4. **自动更新**
   - 任务完成 → 标记✅并移动到已完成区
   - 任务开始 → 标记🔄并移动到进行中区
   - 新任务创建 → 添加到待处理区
   - 自动更新统计数据和进度条

5. **安全机制**
   - 更新前自动备份看板
   - 文件锁检测（避免编辑冲突）
   - 详细的更新日志

## 🚀 使用方法

### 方式1: 手动触发

```bash
# 运行一次同步
python services/task_board_auto_sync.py
```

### 方式2: 定时任务（推荐）

```bash
# 启动定时调度器（每10分钟自动同步）
python services/task_board_scheduler.py
```

输出示例：
```
======================================================================
🚀 任务看板自动同步调度器
======================================================================
启动时间: 2025-11-19 14:30:00
同步间隔: 每 10 分钟
看板路径: /path/to/docs/tasks/task-board.md
======================================================================

💡 提示:
  - 按 Ctrl+C 停止服务
  - 脚本会自动备份看板
  - 同步日志保存在 docs/tasks/sync_log.json

🔄 执行首次同步...
```

### 方式3: API触发

```bash
# 触发同步
curl -X POST http://localhost:8870/api/task-board/sync

# 查看同步状态
curl http://localhost:8870/api/task-board/status

# 检查不一致
curl http://localhost:8870/api/task-board/inconsistencies
```

## 📊 API端点

### POST /api/task-board/sync

触发看板同步

**响应示例:**
```json
{
  "success": true,
  "message": "成功同步 3 个任务",
  "details": {
    "inconsistencies": 3,
    "updated": 2,
    "added": 1,
    "backup": "/path/to/backup/task-board_20251119_143000.md"
  }
}
```

### GET /api/task-board/status

获取同步状态

**响应示例:**
```json
{
  "success": true,
  "board_path": "/path/to/docs/tasks/task-board.md",
  "board_exists": true,
  "last_sync": {
    "timestamp": "2025-11-19T14:30:00",
    "success": true,
    "inconsistencies_found": 3,
    "tasks_updated": 2,
    "tasks_added": 1
  },
  "backup_dir": "/path/to/docs/tasks/backups"
}
```

### GET /api/task-board/inconsistencies

检查看板与数据库的不一致

**响应示例:**
```json
{
  "success": true,
  "count": 2,
  "inconsistencies": [
    {
      "task_id": "REQ-001",
      "title": "端口冲突解决方案",
      "db_status": "completed",
      "board_status": "in_progress",
      "action": "update_status",
      "line_number": 125
    },
    {
      "task_id": "TASK-AUTO-001",
      "title": "实现自动化看板刷新脚本",
      "db_status": "in_progress",
      "board_status": null,
      "action": "add_to_board",
      "priority": "P1",
      "estimated_hours": 2.0
    }
  ]
}
```

## 🔧 配置说明

### 文件路径

- **看板文件**: `docs/tasks/task-board.md`
- **数据库**: `database/data/tasks.db`
- **备份目录**: `docs/tasks/backups/`
- **同步日志**: `docs/tasks/sync_log.json`

### 状态映射

| 数据库状态 | 看板Emoji | 说明 |
|-----------|----------|------|
| pending | ⏳ | 待处理 |
| in_progress | 🔄 | 进行中 |
| completed | ✅ | 已完成 |
| cancelled | ❌ | 已取消 |
| blocked | 🚫 | 已阻塞 |

## 📝 同步日志

同步日志保存在 `docs/tasks/sync_log.json`，包含：

```json
{
  "timestamp": "2025-11-19T14:30:00",
  "success": true,
  "inconsistencies_found": 3,
  "inconsistencies": [...],
  "tasks_updated": 2,
  "tasks_added": 1
}
```

最多保留最近100条日志。

## 🔒 安全机制

### 1. 自动备份

每次更新前自动备份看板文件到 `docs/tasks/backups/`

备份文件命名格式: `task-board_YYYYMMDD_HHMMSS.md`

### 2. 文件锁检测

- 检查 `.lock` 文件，避免编辑冲突
- 锁文件超过5分钟自动清除
- 如果检测到锁定，跳过本次同步

### 3. 格式保护

- 只更新任务状态和统计数据
- 不改变看板的整体结构和格式
- 保留所有注释和说明文字

## 🎨 看板格式要求

脚本依赖以下看板格式：

### 任务行格式

```markdown
**TASK-ID** ✅ 任务标题 (2.0h)
   - 执行者: fullstack-engineer
```

### 区域标记

- 已完成: `### ✅ 已完成任务`
- 进行中: `#### 🔄 进行中`
- 待处理: `#### ⏳ P0任务清单`
- 已取消: `### ❌ 已取消任务`

### 统计数据

```markdown
- **总任务**: 56个
- **已完成**: 29个 (51.8%) ✅
- **进行中**: 1个 🔄
- **待处理**: 22个 ⏳
```

## 🐛 故障排查

### 问题1: 同步失败

**症状**: 脚本运行但没有更新看板

**排查步骤**:
1. 检查数据库是否存在: `ls -la database/data/tasks.db`
2. 检查看板文件是否存在: `ls -la docs/tasks/task-board.md`
3. 查看同步日志: `cat docs/tasks/sync_log.json`
4. 检查文件权限

### 问题2: 格式错误

**症状**: 看板格式被破坏

**解决方案**:
1. 从备份恢复: `cp docs/tasks/backups/task-board_*.md docs/tasks/task-board.md`
2. 检查看板格式是否符合要求
3. 手动修复格式后重新运行

### 问题3: 文件被锁定

**症状**: 提示"看板文件正在被编辑"

**解决方案**:
1. 关闭正在编辑看板的程序
2. 删除锁文件: `rm docs/tasks/task-board.md.lock`
3. 重新运行同步

## 📈 性能优化

- 使用 SQLite 索引加速查询
- 批量处理任务更新
- 增量更新（只更新变化的部分）
- 备份文件自动清理（保留最近20个）

## 🔄 与其他服务集成

### 与事件流集成

脚本读取 `project_events` 表，获取最新的任务事件：

```python
from services.event_service import EventStore

event_store = EventStore(db_path="database/data/tasks.db")
events = event_store.query(category="task", limit=100)
```

### 与状态管理集成

配合 `task_status_poller.py` 使用，实现完整的自动化：

1. `task_status_poller.py` - 监控文件系统，自动更新数据库
2. `task_board_auto_sync.py` - 从数据库同步到看板

## 📚 相关文档

- [任务看板](../../docs/tasks/task-board.md)
- [事件系统文档](../../docs/features/event-system.md)
- [任务状态监控](./task_status_poller.py)

## 🎯 验收标准

- [x] 脚本可以正常运行
- [x] 能检测出看板和数据库的不一致
- [x] 能自动更新看板markdown
- [x] 更新日志清晰
- [x] 不会破坏看板格式
- [x] 备份机制完善
- [x] 冲突检测有效
- [x] API端点可用

## 📞 支持

如有问题，请：
1. 查看同步日志: `docs/tasks/sync_log.json`
2. 查看备份文件: `docs/tasks/backups/`
3. 提交Issue或联系开发团队

---

**开发者**: fullstack-engineer  
**任务ID**: TASK-AUTO-001  
**完成时间**: 2025-11-19  
**版本**: v1.0

