#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""检查Noah的任务数据"""

import sqlite3
import sys

try:
    conn = sqlite3.connect('database/data/tasks.db')
    cursor = conn.cursor()
    
    # 查询分配给Noah的任务
    cursor.execute("""
        SELECT id, title, status, priority, estimated_hours, assigned_to, created_at
        FROM tasks 
        WHERE assigned_to IN ('noah', 'code-steward')
        ORDER BY 
            CASE status 
                WHEN 'in_progress' THEN 1
                WHEN 'pending' THEN 2
                WHEN 'completed' THEN 3
                ELSE 4
            END,
            priority,
            created_at DESC
    """)
    
    tasks = cursor.fetchall()
    print(f"Noah的任务数量: {len(tasks)}")
    print("\n任务列表:")
    print("-" * 100)
    
    for task in tasks[:15]:
        id, title, status, priority, hours, assigned, created = task
        title_short = title[:60] if len(title) > 60 else title
        print(f"{id:4} | {status:12} | {priority:6} | {hours:4}h | {title_short}")
    
    if len(tasks) > 15:
        print(f"\n... 还有 {len(tasks) - 15} 个任务")
    
    conn.close()
    print("\n✅ 数据库查询成功")
    
except Exception as e:
    print(f"❌ 错误: {e}", file=sys.stderr)
    sys.exit(1)

