#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dashboard前端记忆空间功能测试脚本

测试内容：
1. 记忆空间页面加载
2. 记忆空间API功能
3. 测试工程师模块已移除
4. 用户终测模块已保留
"""

import requests
import sys
from datetime import datetime

BASE_URL = "http://localhost:8877"
TIMEOUT = 5


def test_memory_page():
    """测试记忆空间页面"""
    print("\n[测试1] 记忆空间页面加载...")
    try:
        response = requests.get(f"{BASE_URL}/memories", timeout=TIMEOUT)
        assert response.status_code == 200, f"状态码错误: {response.status_code}"
        assert "项目记忆空间" in response.text, "页面标题缺失"
        assert "Memory Space" in response.text, "英文标题缺失"
        print("  ✅ 记忆空间页面加载正常")
        print(f"     - 页面大小: {len(response.text)} 字符")
        print(f"     - 访问地址: {BASE_URL}/memories")
        return True
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return False


def test_memory_list_api():
    """测试记忆列表API"""
    print("\n[测试2] 记忆列表API...")
    try:
        response = requests.get(
            f"{BASE_URL}/api/memories/list",
            params={"limit": 5},
            timeout=TIMEOUT
        )
        assert response.status_code == 200, f"状态码错误: {response.status_code}"
        data = response.json()
        assert "memories" in data, "返回数据格式错误"
        assert isinstance(data["memories"], list), "memories字段不是列表"
        
        print(f"  ✅ 记忆列表API正常")
        print(f"     - 返回记忆数: {len(data['memories'])} 条")
        print(f"     - API地址: {BASE_URL}/api/memories/list")
        return True
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return False


def test_memory_stats_api():
    """测试记忆统计API"""
    print("\n[测试3] 记忆统计API...")
    try:
        response = requests.get(
            f"{BASE_URL}/api/memories/stats",
            timeout=TIMEOUT
        )
        assert response.status_code == 200, f"状态码错误: {response.status_code}"
        data = response.json()
        assert "stats" in data, "返回数据格式错误"
        
        stats = data["stats"]
        total = stats.get("total_memories", 0)
        
        print(f"  ✅ 记忆统计API正常")
        print(f"     - 总记忆数: {total} 条")
        print(f"     - 架构类: {stats.get('by_category', {}).get('architecture', 0)} 条")
        print(f"     - 决策类: {stats.get('by_category', {}).get('decision', 0)} 条")
        print(f"     - 解决方案类: {stats.get('by_category', {}).get('solution', 0)} 条")
        return True
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return False


def test_memory_search_api():
    """测试记忆搜索API"""
    print("\n[测试4] 记忆搜索API...")
    try:
        response = requests.get(
            f"{BASE_URL}/api/memories/search",
            params={"q": "架构", "limit": 10},
            timeout=TIMEOUT
        )
        assert response.status_code == 200, f"状态码错误: {response.status_code}"
        data = response.json()
        assert "memories" in data, "返回数据格式错误"
        
        print(f"  ✅ 记忆搜索API正常")
        print(f"     - 搜索关键词: '架构'")
        print(f"     - 匹配结果: {len(data['memories'])} 条")
        return True
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return False


def test_tester_module_removed():
    """测试测试工程师模块已移除"""
    print("\n[测试5] 测试工程师模块已移除...")
    try:
        response = requests.get(f"{BASE_URL}/", timeout=TIMEOUT)
        assert response.status_code == 200, f"状态码错误: {response.status_code}"
        
        # 不应该包含"测试工程师"（但可能包含"测试"字样）
        assert "◇ 测试工程师" not in response.text, "测试工程师模块仍然存在"
        
        print("  ✅ 测试工程师模块已成功移除")
        print("     - HTML中不再包含测试工程师模块")
        return True
    except AssertionError as e:
        print(f"  ❌ 失败: {e}")
        return False
    except Exception as e:
        print(f"  ❌ 错误: {e}")
        return False


def test_user_testing_kept():
    """测试用户终测模块已保留"""
    print("\n[测试6] 用户终测模块已保留...")
    try:
        response = requests.get(f"{BASE_URL}/", timeout=TIMEOUT)
        assert response.status_code == 200, f"状态码错误: {response.status_code}"
        
        # 应该包含"目标用户终测"
        assert "◉ 目标用户终测" in response.text, "用户终测模块缺失"
        assert "7位模拟用户" in response.text, "用户终测内容缺失"
        
        print("  ✅ 用户终测模块已成功保留")
        print("     - HTML中包含用户终测模块")
        print("     - 包含7位模拟用户提示词")
        return True
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return False


def test_dashboard_health():
    """测试Dashboard健康状态"""
    print("\n[测试0] Dashboard健康检查...")
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
        assert response.status_code == 200, f"状态码错误: {response.status_code}"
        data = response.json()
        assert data.get("status") == "healthy", "服务状态异常"
        
        print("  ✅ Dashboard服务运行正常")
        print(f"     - 服务地址: {BASE_URL}")
        print(f"     - 时间戳: {data.get('timestamp')}")
        return True
    except requests.exceptions.ConnectionError:
        print(f"  ❌ 无法连接到Dashboard")
        print(f"     请先启动: python apps/dashboard/start_dashboard.py")
        return False
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return False


def main():
    """主测试函数"""
    print("=" * 70)
    print("Dashboard前端记忆空间功能测试")
    print("=" * 70)
    print(f"\n测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Dashboard地址: {BASE_URL}")
    
    # 运行所有测试
    tests = [
        ("健康检查", test_dashboard_health),
        ("记忆空间页面", test_memory_page),
        ("记忆列表API", test_memory_list_api),
        ("记忆统计API", test_memory_stats_api),
        ("记忆搜索API", test_memory_search_api),
        ("测试模块移除", test_tester_module_removed),
        ("用户终测保留", test_user_testing_kept),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"\n  ❌ 测试异常: {e}")
            results.append((name, False))
    
    # 统计结果
    print("\n" + "=" * 70)
    print("测试结果汇总")
    print("=" * 70)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ 通过" if result else "❌ 失败"
        print(f"  {status} - {name}")
    
    print()
    print(f"总计: {passed}/{total} 测试通过")
    print(f"通过率: {passed/total*100:.1f}%")
    
    if passed == total:
        print("\n🎉 所有测试通过！记忆空间功能正常！")
        print("=" * 70)
        return 0
    else:
        print(f"\n⚠️  {total-passed} 个测试失败，请检查")
        print("=" * 70)
        return 1


if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n⚠️  测试被用户中断")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ 测试过程出错: {e}")
        sys.exit(1)

