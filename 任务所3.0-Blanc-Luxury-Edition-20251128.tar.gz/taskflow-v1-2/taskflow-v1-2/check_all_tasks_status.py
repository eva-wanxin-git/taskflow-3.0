import sqlite3
from pathlib import Path

db_path = Path(__file__).parent / "database" / "data" / "tasks.db"
conn = sqlite3.connect(str(db_path))
cursor = conn.cursor()

print("数据库中所有任务:")
cursor.execute("SELECT COUNT(*) FROM tasks")
print(f"总数: {cursor.fetchone()[0]}")

print("\n按project_id分组:")
cursor.execute("SELECT project_id, COUNT(*) FROM tasks GROUP BY project_id")
for row in cursor.fetchall():
    print(f"  {row[0]}: {row[1]}个")

print("\nTASKFLOW项目任务状态分布:")
cursor.execute("""
    SELECT status, COUNT(*) 
    FROM tasks 
    WHERE project_id='TASKFLOW' OR project_id IS NULL OR project_id=''
    GROUP BY status
""")
for row in cursor.fetchall():
    print(f"  {row[0]}: {row[1]}个")

conn.close()

