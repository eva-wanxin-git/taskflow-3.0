"""检查架构师工作台数据"""
import sqlite3
import json
from datetime import datetime
import sys
import io

# 设置Windows终端编码
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 连接数据库
conn = sqlite3.connect('database/data/tasks.db')
cursor = conn.cursor()

print("=" * 60)
print("架构师工作台数据检查")
print("=" * 60)

# 1. 检查架构相关事件
print("\n[1] 架构相关事件 (project_events)")
print("-" * 60)
cursor.execute("""
    SELECT event_type, title, occurred_at, severity, actor 
    FROM project_events 
    WHERE project_id='TASKFLOW' 
      AND (event_category='architecture' OR event_category='decision')
    ORDER BY occurred_at DESC 
    LIMIT 10
""")

events = cursor.fetchall()
print(f"找到 {len(events)} 条架构事件（显示最近10条）\n")

for i, event in enumerate(events, 1):
    event_type, title, time, severity, actor = event
    print(f"{i}. [{severity}] {title}")
    print(f"   类型: {event_type}")
    print(f"   时间: {time}")
    print(f"   操作人: {actor}")
    print()

# 2. 检查所有事件类别统计
print("\n[2] 事件类别统计")
print("-" * 60)
cursor.execute("""
    SELECT event_category, COUNT(*) as count
    FROM project_events 
    WHERE project_id='TASKFLOW'
    GROUP BY event_category
    ORDER BY count DESC
""")

categories = cursor.fetchall()
for category, count in categories:
    print(f"  {category}: {count} 条")

# 3. 检查对话历史
print("\n[3] 对话历史 (conversations)")
print("-" * 60)
cursor.execute("""
    SELECT id, title, created_at, metadata
    FROM conversations 
    WHERE project_id='TASKFLOW' 
    ORDER BY created_at DESC
    LIMIT 5
""")

conversations = cursor.fetchall()
print(f"找到 {len(conversations)} 条对话记录（显示最近5条）\n")

for i, conv in enumerate(conversations, 1):
    conv_id, title, created_at, metadata = conv
    print(f"{i}. {title}")
    print(f"   ID: {conv_id}")
    print(f"   创建时间: {created_at}")
    if metadata:
        try:
            meta = json.loads(metadata)
            if 'role' in meta:
                print(f"   角色: {meta['role']}")
        except:
            pass
    print()

# 4. 统计总数
print("\n[4] 数据总览")
print("-" * 60)

cursor.execute("SELECT COUNT(*) FROM project_events WHERE project_id='TASKFLOW'")
total_events = cursor.fetchone()[0]

cursor.execute("SELECT COUNT(*) FROM conversations WHERE project_id='TASKFLOW'")
total_conversations = cursor.fetchone()[0]

print(f"  总事件数: {total_events}")
print(f"  总对话数: {total_conversations}")

conn.close()

print("\n" + "=" * 60)
print("检查完成")
print("=" * 60)

