import json
from pathlib import Path

data_dir = Path("apps/dashboard/automation-data")

files = [
    "v17-complete-features.json",
    "partial-features.json", 
    "project-issues.json",
    "architecture-suggestions.json"
]

print("=" * 60)
print("检查所有JSON文件的数据量")
print("=" * 60)
print()

for filename in files:
    filepath = data_dir / filename
    if filepath.exists():
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        print(f"{filename}:")
        
        if "implemented" in data:
            print(f"  implemented: {len(data['implemented'])}个")
        if "partial_features" in data:
            print(f"  partial_features: {len(data['partial_features'])}个 (total: {data.get('total', 'N/A')})")
        if "issues" in data:
            print(f"  issues: {len(data['issues'])}个 (total: {data.get('total', 'N/A')})")
        if "suggestions" in data:
            print(f"  suggestions: {len(data['suggestions'])}个 (total: {data.get('total', 'N/A')})")
        
        print(f"  updated_at: {data.get('updated_at', 'N/A')}")
        print()
    else:
        print(f"{filename}: NOT FOUND")
        print()

print("=" * 60)



