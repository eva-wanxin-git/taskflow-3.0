#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
测试透视塔API端点
验证所有4个Tab的数据端点是否正常工作
"""
import requests
import json

API_BASE = "http://localhost:8800/api"

def test_api_endpoint(name, url):
    """测试单个API端点"""
    print(f"\n{'='*60}")
    print(f"测试: {name}")
    print(f"URL: {url}")
    print(f"{'='*60}")
    
    try:
        response = requests.get(url, timeout=5)
        print(f"✅ 状态码: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ 响应数据:")
            print(json.dumps(data, indent=2, ensure_ascii=False)[:500] + "...")
            return True
        else:
            print(f"❌ 错误: {response.text}")
            return False
    except requests.exceptions.ConnectionError:
        print(f"❌ 连接失败: API服务未运行 (端口8800)")
        return False
    except Exception as e:
        print(f"❌ 异常: {str(e)}")
        return False

def main():
    print("\n" + "="*60)
    print("透视塔API端点测试".center(60))
    print("="*60)
    
    tests = [
        ("Tab1: 已实现功能", f"{API_BASE}/features/implemented"),
        ("Tab2: 部分实现", f"{API_BASE}/features/partial"),
        ("Tab3: 问题清单", f"{API_BASE}/issues"),
        ("Tab4: 架构建议", f"{API_BASE}/suggestions"),
        ("汇总: 功能概况", f"{API_BASE}/features/summary"),
    ]
    
    results = []
    for name, url in tests:
        result = test_api_endpoint(name, url)
        results.append((name, result))
    
    # 总结
    print("\n" + "="*60)
    print("测试总结".center(60))
    print("="*60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ 通过" if result else "❌ 失败"
        print(f"{status} - {name}")
    
    print(f"\n通过率: {passed}/{total} ({passed/total*100:.1f}%)")
    
    if passed == total:
        print("\n🎉 所有API端点测试通过！")
        print("\n下一步:")
        print("1. 刷新浏览器: http://localhost:8820")
        print("2. 点击透视塔的4个Tab，查看数据加载")
        print("3. 检查浏览器Console查看API调用日志")
    else:
        print("\n⚠️ 部分API端点测试失败")
        print("\n解决方法:")
        print("1. 启动API服务: cd apps/api && python3 start_api.py")
        print("2. 确认8800端口未被占用")
        print("3. 重新运行此测试脚本")

if __name__ == "__main__":
    main()

