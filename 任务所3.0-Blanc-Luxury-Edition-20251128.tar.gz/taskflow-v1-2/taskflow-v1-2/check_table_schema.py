import sqlite3
from pathlib import Path

db_path = Path(__file__).parent / "database" / "data" / "tasks.db"
conn = sqlite3.connect(str(db_path))
cursor = conn.cursor()

cursor.execute('PRAGMA table_info(tasks)')
print('tasks table columns:')
for row in cursor.fetchall():
    print(f'  {row[1]:20s} {row[2]}')
conn.close()

