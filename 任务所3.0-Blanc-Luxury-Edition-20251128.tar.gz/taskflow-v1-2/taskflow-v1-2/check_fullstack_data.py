#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""检查全栈工程师工作台数据"""
import sqlite3
import json
import sys
import io

# 修复Windows控制台编码
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def check_tasks():
    """检查任务数据"""
    conn = sqlite3.connect('database/data/tasks.db')
    cursor = conn.cursor()
    
    # 1. 总任务数
    cursor.execute('SELECT COUNT(*) FROM tasks WHERE project_id="TASKFLOW"')
    total = cursor.fetchone()[0]
    print(f"\n[OK] 总任务数: {total}")
    
    # 2. 按状态分组
    cursor.execute('''
        SELECT status, COUNT(*) 
        FROM tasks 
        WHERE project_id="TASKFLOW" 
        GROUP BY status
    ''')
    print("\n[DATA] 按状态分组:")
    status_map = {
        'pending': '待处理',
        'in_progress': '进行中',
        'completed': '已完成',
        'blocked': '受阻',
        'cancelled': '已取消'
    }
    for row in cursor.fetchall():
        status, count = row
        status_cn = status_map.get(status, status)
        print(f"  {status_cn} ({status}): {count}个")
    
    # 3. 每列的任务详情
    for status in ['pending', 'in_progress', 'completed']:
        cursor.execute('''
            SELECT id, title, priority, estimated_hours
            FROM tasks 
            WHERE project_id="TASKFLOW" AND status=?
            ORDER BY priority, created_at DESC
            LIMIT 5
        ''', (status,))
        
        tasks = cursor.fetchall()
        status_cn = status_map.get(status, status)
        print(f"\n[LIST] {status_cn} - 前5个任务:")
        for task in tasks:
            task_id, title, priority, hours = task
            print(f"  [{task_id}] {title} (P{priority}, {hours}h)")
    
    conn.close()

if __name__ == '__main__':
    check_tasks()

