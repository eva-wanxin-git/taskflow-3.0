#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sqlite3

conn = sqlite3.connect('database/data/tasks.db')
cursor = conn.cursor()

# 检查issues表
cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='issues'")
has_issues = cursor.fetchone() is not None

issues_data = []
if has_issues:
    # 先查看表结构
    cursor.execute("PRAGMA table_info(issues)")
    columns = cursor.fetchall()
    print("issues表字段:", [col[1] for col in columns])
    
    cursor.execute("SELECT * FROM issues LIMIT 20")
    issues_data = cursor.fetchall()

# 检查knowledge_articles表
cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='knowledge_articles'")
has_kb = cursor.fetchone() is not None

kb_data = []
if has_kb:
    # 先查看表结构
    cursor.execute("PRAGMA table_info(knowledge_articles)")
    columns = cursor.fetchall()
    print("knowledge_articles表字段:", [col[1] for col in columns])
    
    cursor.execute("SELECT * FROM knowledge_articles LIMIT 20")
    kb_data = cursor.fetchall()

print('\n=== 数据检查结果 ===')
print(f'issues表存在: {has_issues}')
print(f'issues数据量: {len(issues_data)}')
if issues_data:
    print('前3条issues:')
    for i, issue in enumerate(issues_data[:3], 1):
        print(f'  {i}. {issue}')

print(f'\nknowledge_articles表存在: {has_kb}')
print(f'knowledge_articles数据量: {len(kb_data)}')
if kb_data:
    print('前3条知识文章:')
    for i, kb in enumerate(kb_data[:3], 1):
        print(f'  {i}. {kb}')

conn.close()

