# ✅ 新增MCP工具安装完成 - 代码定位专用

## 📦 已安装的新工具 (2025-11-22)

### 🎯 **1. SQLite MCP** - 数据库精准查询
**用途：** 直接查询和分析数据库
```bash
# 自动配置路径：
/Users/yalinwang/Desktop/任务所 1.8/taskflow-v1-2/taskflow-v1-2/database
```

**核心功能：**
- ✅ 查询数据表结构
- ✅ 执行SQL查询
- ✅ 分析数据关系
- ✅ 快速定位数据库相关代码

**使用示例：**
```sql
-- 查看所有表
SELECT name FROM sqlite_master WHERE type='table';

-- 查询任务数据
SELECT * FROM tasks WHERE status='pending';

-- 分析表结构
PRAGMA table_info(tasks);
```

---

### 🌐 **2. Fetch MCP** - API测试利器
**用途：** 快速测试和验证API端点

**核心功能：**
- ✅ 发送HTTP请求（GET/POST/PUT/DELETE）
- ✅ 测试API响应
- ✅ 验证接口数据格式
- ✅ 调试网络问题

**使用示例：**
```bash
# 测试本地API
GET http://127.0.0.1:8800/api/tasks

# 测试透视塔API
GET http://127.0.0.1:8000/api/insight/modules

# POST请求测试
POST http://127.0.0.1:8800/api/tasks/create
Content-Type: application/json
{
  "title": "测试任务",
  "status": "pending"
}
```

---

### 🔍 **3. Everything MCP** - 全局文件搜索
**用途：** 超快速文件定位（类似Windows Everything）

**配置路径：**
```bash
/Users/yalinwang/Desktop/任务所 1.8/taskflow-v1-2/taskflow-v1-2
```

**核心功能：**
- ✅ 毫秒级文件名搜索
- ✅ 支持通配符和正则
- ✅ 实时索引更新
- ✅ 路径精准定位

**使用示例：**
```bash
# 查找所有API文件
*.py api

# 查找配置文件
config.*

# 查找模板文件
templates/**/*.html
```

---

### 🌍 **4. Brave Search MCP** (已禁用)
**用途：** 网络搜索集成
**状态：** 暂时禁用（需要API Key）

---

## 🚀 使用方法

### **方式1: 语义搜索（智能推荐）**
当您不确定确切位置时：
```python
# 我会自动使用codebase_search
"在哪里初始化了Flask应用？"
"数据库连接的配置在哪？"
"任务创建的逻辑是怎么实现的？"
```

### **方式2: 精确搜索**
知道确切名称时：
```bash
# 使用grep查找函数定义
grep "def create_task"

# 使用SQLite查询数据
SELECT * FROM tasks WHERE module='architect'

# 使用Everything定位文件
find "start_insight_api.py"
```

### **方式3: 组合搜索**
复杂场景下：
```bash
# 1. 先用Everything找到文件
find "*.py" database

# 2. 再用grep查找具体代码
grep "def init_db" path="database/"

# 3. 最后用SQLite验证数据
SELECT * FROM sqlite_master
```

---

## 💡 最佳实践 - 代码定位工作流

### **场景1: 查找模块入口**
```bash
1. Everything搜索 → "start_*.py"
2. grep精确定位 → "def main"
3. codebase_search理解逻辑 → "应用启动流程"
```

### **场景2: 调试API问题**
```bash
1. Fetch测试 → GET /api/endpoint
2. grep查找路由 → "@app.route('/api/endpoint')"
3. SQLite验证数据 → SELECT * FROM table
4. codebase_search → "这个接口的完整调用链"
```

### **场景3: 数据库操作定位**
```bash
1. SQLite查看表结构 → PRAGMA table_info(tasks)
2. grep查找ORM代码 → "class Task"
3. codebase_search → "任务表的增删改查在哪里"
```

---

## 🔥 快速命令参考

### **常用搜索命令**
```bash
# 文件名搜索（最快）
everything: "api*.py"

# 内容搜索（精确）
grep: "def create_app"

# 语义搜索（智能）
codebase_search: "Flask应用的配置在哪"

# 数据库查询
sqlite: "SELECT * FROM tasks LIMIT 10"

# API测试
fetch: "GET http://127.0.0.1:8800/api/tasks"
```

---

## ⚙️ 配置说明

所有工具已自动配置并启用，除了：
- **Brave Search**: 需要API Key，已禁用

如需启用Brave Search：
1. 获取API Key: https://brave.com/search/api/
2. 修改配置文件中的 `BRAVE_API_KEY`
3. 将 `"disabled": true` 改为 `false`

---

## 🎯 与现有工具的协同

| 场景 | 工具组合 | 优势 |
|------|---------|------|
| **模块定位** | Everything + grep + codebase_search | 快速找到→精确定位→理解逻辑 |
| **API调试** | Fetch + SQLite + grep | 测试接口→查数据→找代码 |
| **数据分析** | SQLite + codebase_search | 查数据结构→找相关代码 |
| **全局重构** | Everything + grep + git-automation | 找文件→批量修改→版本控制 |

---

## 📊 工具性能对比

| 工具 | 速度 | 适用场景 | 准确度 |
|-----|------|---------|--------|
| **Everything** | ⚡⚡⚡⚡⚡ | 文件名搜索 | ★★★★★ |
| **grep** | ⚡⚡⚡⚡ | 内容精确搜索 | ★★★★★ |
| **codebase_search** | ⚡⚡⚡ | 语义理解搜索 | ★★★★ |
| **SQLite** | ⚡⚡⚡⚡⚡ | 数据库查询 | ★★★★★ |
| **Fetch** | ⚡⚡⚡⚡ | API测试 | ★★★★★ |

---

## 🔄 重启Cursor生效

**重要：** 请重启Cursor以加载新的MCP工具！

```bash
# macOS重启Cursor
⌘ + Q (退出)
然后重新打开Cursor
```

---

## ✅ 验证安装

重启后，在新对话中说：
```
请列出当前可用的所有MCP工具
```

您应该能看到新增的：
- ✅ sqlite
- ✅ fetch  
- ✅ everything
- ✅ brave-search (禁用状态)

---

## 📝 注意事项

1. **SQLite路径**: 已自动配置为您的database目录
2. **Everything搜索**: 已配置为项目根目录
3. **Fetch无需配置**: 开箱即用
4. **所有工具**: 使用npx自动安装，无需手动安装依赖

---

## 🎉 您现在拥有的完整工具链

### **代码定位** (6种方式)
1. codebase_search - 语义搜索
2. grep - 精确文本搜索
3. Everything - 文件名搜索
4. glob_file_search - 文件模式匹配
5. Desktop Commander search - 流式搜索
6. Sequential Thinking - 逻辑分析

### **数据操作** (3种方式)
1. SQLite MCP - 数据库查询
2. ultra-memory - 智能记忆
3. session-memory - 会话记忆

### **网络工具** (3种方式)
1. Fetch MCP - API测试
2. Puppeteer - 浏览器自动化
3. Browser Tools - 浏览器操作

### **版本控制** (2种方式)
1. git-automation - Git自动化
2. github - GitHub集成

### **系统操作** (4种方式)
1. Desktop Commander - 文件/进程管理
2. filesystem - 文件系统
3. macos-automator - macOS自动化
4. desktop-apps - 应用管理

---

## 🚀 立即体验

重启Cursor后，尝试这些命令：

```bash
# 1. 查找所有Python API文件
"使用Everything查找所有包含api的Python文件"

# 2. 查询数据库
"使用SQLite查看tasks表的结构"

# 3. 测试API
"使用Fetch测试 http://127.0.0.1:8800/api/tasks 接口"

# 4. 语义搜索
"Flask应用的初始化和配置都在哪些文件里？"
```

---

**安装时间**: 2025-11-22
**安装者**: AI助手
**状态**: ✅ 完成，等待Cursor重启生效

