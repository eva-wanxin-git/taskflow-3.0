#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Blanc Luxury Edition - 快速测试脚本
验证模块导入和数据提供器是否正常工作
"""
import sys
from pathlib import Path

# 添加src到路径
sys.path.insert(0, str(Path(__file__).parent / "src"))

print("=" * 70)
print(" Blanc Luxury Edition - 快速测试 ".center(70))
print("=" * 70)
print()

# 测试1: 导入模块
print("[测试1] 导入模块...")
try:
    from industrial_dashboard.templates_blanc_luxury import get_blanc_luxury_dashboard
    from industrial_dashboard.templates_blanc_luxury import _format_events_for_display, _calculate_time_ago
    print("✅ 模块导入成功")
except Exception as e:
    print(f"❌ 模块导入失败: {e}")
    sys.exit(1)

# 测试2: 导入数据提供器
print("\n[测试2] 导入数据提供器...")
try:
    from industrial_dashboard.adapters import StateManagerAdapter
    from industrial_dashboard.event_stream_provider import EventStreamProvider
    from industrial_dashboard.project_memory_provider import ProjectMemoryProvider
    print("✅ 数据提供器导入成功")
except Exception as e:
    print(f"❌ 数据提供器导入失败: {e}")
    sys.exit(1)

# 测试3: 测试时间计算函数
print("\n[测试3] 测试时间计算函数...")
try:
    from datetime import datetime
    test_time = datetime.now().isoformat()
    result = _calculate_time_ago(test_time)
    print(f"✅ 时间计算成功: {result}")
except Exception as e:
    print(f"❌ 时间计算失败: {e}")

# 测试4: 测试事件格式化函数
print("\n[测试4] 测试事件格式化...")
try:
    test_events = [
        {
            'occurred_at': datetime.now().isoformat(),
            'title': '测试事件',
            'description': '这是一个测试事件',
            'severity': 'info',
            'category': 'task',
            'actor': 'Test User',
            'event_id': 'test-001'
        }
    ]
    formatted = _format_events_for_display(test_events)
    print(f"✅ 事件格式化成功: {len(formatted)} 个事件")
    if formatted:
        print(f"   示例事件: {formatted[0]['title']}")
except Exception as e:
    print(f"❌ 事件格式化失败: {e}")

# 测试5: 检查模板生成（模拟数据）
print("\n[测试5] 测试模板生成（使用模拟数据）...")
try:
    # 创建模拟数据提供器
    class MockProvider:
        def get_stats(self):
            class Stats:
                total_tasks = 57
                completed_tasks = 29
                pending_tasks = 24
                in_progress_tasks = 4
            return Stats()
        
        def get_event_stats(self):
            return {
                'total_events': 156,
                'warning_events': 8,
                'error_events': 2
            }
        
        def get_recent_events(self, hours=24, limit=5):
            return []
        
        def get_memory_stats(self):
            return {
                'total_memories': 45,
                'decision_memories': 12,
                'solution_memories': 23
            }
    
    mock_data = MockProvider()
    mock_events = MockProvider()
    mock_memory = MockProvider()
    
    html = get_blanc_luxury_dashboard(
        data_provider=mock_data,
        event_provider=mock_events,
        memory_provider=mock_memory
    )
    
    # 验证HTML包含关键元素
    assert "<!DOCTYPE html>" in html
    assert "Blanc Luxury" in html
    assert "任务所·Flow" in html
    assert "系统脉搏" in html
    assert "实时脉动" in html
    
    print(f"✅ 模板生成成功")
    print(f"   HTML长度: {len(html)} 字符")
    print(f"   包含关键元素: ✓")
    
except Exception as e:
    print(f"❌ 模板生成失败: {e}")
    import traceback
    traceback.print_exc()

print()
print("=" * 70)
print(" 测试完成！".center(70))
print("=" * 70)
print()
print("如果所有测试都通过，您可以运行:")
print("  python start_blanc_luxury.py")
print()
print("然后访问: http://127.0.0.1:8878/blanc")
print()

