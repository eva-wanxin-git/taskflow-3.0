# 📦 Apps - 应用层

可独立部署的应用程序

## 目录

- `api/` - 后端API服务（FastAPI）
- `dashboard/` - Web Dashboard前端
- `worker/` - 后台Worker服务

---

**状态**: 🔨 待迁移

