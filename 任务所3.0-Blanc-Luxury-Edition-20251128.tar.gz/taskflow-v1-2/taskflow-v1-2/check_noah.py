import sqlite3
conn = sqlite3.connect('database/data/tasks.db')
cursor = conn.cursor()
cursor.execute('SELECT COUNT(*) FROM tasks WHERE assigned_to IN ("noah", "code-steward")')
count = cursor.fetchone()[0]
print(f'Noah tasks: {count}')
conn.close()

