#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""检查当前数据库任务状态"""
import sqlite3
from pathlib import Path

db_path = Path(__file__).parent / "database" / "data" / "tasks.db"

conn = sqlite3.connect(str(db_path))
cursor = conn.cursor()

print("=" * 60)
print("任务所·Flow - 当前任务状态")
print("=" * 60)
print()

# 总任务数
cursor.execute("SELECT COUNT(*) FROM tasks WHERE project_id='TASKFLOW'")
total = cursor.fetchone()[0]
print(f"总任务数: {total}")
print()

# 按状态统计
print("任务状态分布:")
cursor.execute("""
    SELECT status, COUNT(*) 
    FROM tasks 
    WHERE project_id='TASKFLOW' 
    GROUP BY status
    ORDER BY COUNT(*) DESC
""")
for row in cursor.fetchall():
    print(f"  {row[0]:15s}: {row[1]:3d}个")
print()

# 按优先级统计
print("任务优先级分布:")
cursor.execute("""
    SELECT priority, COUNT(*) 
    FROM tasks 
    WHERE project_id='TASKFLOW' 
    GROUP BY priority
    ORDER BY priority
""")
for row in cursor.fetchall():
    print(f"  {row[0]:5s}: {row[1]:3d}个")
print()

# 最近的5个任务
print("最近创建的5个任务:")
cursor.execute("""
    SELECT id, title, status, priority 
    FROM tasks 
    WHERE project_id='TASKFLOW' 
    ORDER BY created_at DESC 
    LIMIT 5
""")
for row in cursor.fetchall():
    print(f"  [{row[2]:12s}] {row[0]:20s} - {row[1][:50]}")

conn.close()
print()
print("=" * 60)

