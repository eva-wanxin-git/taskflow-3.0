#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""检查HTML结构的闭合情况"""

with open('index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# 找到运维模块开始
devops_start = 10878  # <!-- ========== 运维工程师工作台 ========== -->
noah_start = 11578    # <!-- ========== Noah AI代码管家模块 ========== -->

print("=" * 80)
print("运维模块到Noah模块之间的闭合标签分析")
print("=" * 80)
print()

# 统计div标签
open_divs = 0
open_positions = []
close_positions = []

for i in range(devops_start - 1, noah_start - 1):
    line = lines[i]
    line_num = i + 1
    
    # 统计开标签
    if '<div' in line:
        open_count = line.count('<div')
        open_divs += open_count
        if open_count > 0:
            open_positions.append((line_num, line.strip()[:100]))
    
    # 统计闭标签  
    if '</div>' in line:
        close_count = line.count('</div>')
        open_divs -= close_count
        if close_count > 0:
            close_positions.append((line_num, line.strip()[:100]))

print(f"运维模块区域 (行{devops_start} - {noah_start-1}):")
print(f"- 开始标签 <div> 数量: {len(open_positions)}")
print(f"- 结束标签 </div> 数量: {len(close_positions)}")
print(f"- 最终平衡: {open_divs} (应该为0)")
print()

if open_divs > 0:
    print("❌ 警告：有未闭合的div标签！Noah模块可能被嵌套在运维模块里面")
    print()
    print("最后5个开始标签:")
    for line_num, content in open_positions[-5:]:
        print(f"  {line_num}: {content}")
    print()
    print("最后5个结束标签:")
    for line_num, content in close_positions[-5:]:
        print(f"  {line_num}: {content}")
elif open_divs < 0:
    print("❌ 警告：结束标签多于开始标签！")
else:
    print("✅ 标签配对正常")

# 检查运维模块的最后一个div
print()
print("=" * 80)
print("运维模块最后20行:")
print("=" * 80)
for i in range(noah_start - 20, noah_start):
    print(f"{i+1}: {lines[i].rstrip()}")

