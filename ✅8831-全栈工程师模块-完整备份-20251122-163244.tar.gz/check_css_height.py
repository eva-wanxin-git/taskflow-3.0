#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""检查所有模块的CSS height设置"""
import re

with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

modules = [
    'page-container',
    'pending-features-module', 
    'architect-module',
    'engineer-module',
    'devops-module',
    'code-manager-module',
    'memory-space-module',
    'pulse-module'
]

print("="*80)
print("所有模块的height/min-height设置检查")
print("="*80)
print()

for module in modules:
    # 查找模块CSS定义
    pattern = rf'\.{module}\s*\{{([^}}]+)\}}'
    match = re.search(pattern, content, re.DOTALL)
    
    if match:
        css_block = match.group(1)
        
        # 提取关键属性
        height_match = re.search(r'height:\s*([^;]+)', css_block)
        min_height_match = re.search(r'min-height:\s*([^;]+)', css_block)
        max_width_match = re.search(r'max-width:\s*([^;]+)', css_block)
        margin_match = re.search(r'margin:\s*([^;]+)', css_block)
        
        height_val = height_match.group(1).strip() if height_match else "未设置"
        min_height_val = min_height_match.group(1).strip() if min_height_match else "未设置"
        max_width_val = max_width_match.group(1).strip() if max_width_match else "未设置"
        margin_val = margin_match.group(1).strip() if margin_match else "未设置"
        
        print(f"{module}:")
        print(f"  max-width: {max_width_val}")
        print(f"  margin: {margin_val}")
        print(f"  height: {height_val}")
        print(f"  min-height: {min_height_val}")
        
        # 判断问题
        if 'calc(100vh' in height_val or 'calc(100vh' in min_height_val:
            print(f"  !!! 警告：使用了100vh，可能导致过高")
        if height_val == "100%":
            print(f"  !!! 警告：height: 100% 可能导致延伸")
        if max_width_val == "未设置":
            print(f"  !!! 警告：缺少max-width，会填满容器")
            
        print()

