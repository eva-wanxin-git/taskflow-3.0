with open('index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

modules = [
    (8886, 11075, 'Engineer->Memory'),
    (11078, 11410, 'Memory->Pulse'),
    (11410, 12155, 'Pulse->DevOps'),
    (12155, 12855, 'DevOps->Noah')
]

print('Module Balance Check:')
print('-' * 60)

for start, end, name in modules:
    div_open = sum(l.count('<div') for l in lines[start-1:end-1])
    div_close = sum(l.count('</div>') for l in lines[start-1:end-1])
    diff = div_open - div_close
    status = 'OK' if diff == 0 else f'ERROR (diff={diff})'
    print(f'{name:20s}: open={div_open:3d}, close={div_close:3d}, {status}')

