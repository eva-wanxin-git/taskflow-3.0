
import re

def find_line(lines, pattern):
    for i, line in enumerate(lines):
        if pattern in line:
            return i + 1
    return -1

def remove_comments(text):
    return re.sub(r'<!--.*?-->', '', text, flags=re.DOTALL)

def count_balance(lines, start, end, name):
    # Join lines to handle multi-line comments
    text = "".join(lines[start-1:end-1])
    text_no_comments = remove_comments(text)
    
    open_count = text_no_comments.count('<div')
    close_count = text_no_comments.count('</div>')
    
    print(f"Section: {name} (Lines {start}-{end})")
    print(f"  Open: {open_count}")
    print(f"  Close: {close_count}")
    print(f"  Diff: {open_count - close_count}")
    
    if open_count == close_count:
        print("  OK Balanced")
    else:
        print("  FAIL Unbalanced")
        
    # Stack trace for debugging if needed (simplified)
    # ...

with open('index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Find markers
engineer_start = find_line(lines, 'class="engineer-module')
memory_start = find_line(lines, 'class="memory-space-module')
pulse_start = find_line(lines, 'class="pulse-module')
devops_start = find_line(lines, 'class="devops-module')
noah_start = find_line(lines, 'class="code-manager-module')
footer_start = find_line(lines, '<footer')

print("Markers found:")
print(f"Engineer: {engineer_start}")
print(f"Memory: {memory_start}")
print(f"Pulse: {pulse_start}")
print(f"DevOps: {devops_start}")
print(f"Noah: {noah_start}")
print(f"Footer: {footer_start}")
print("-" * 40)

if engineer_start > 0 and memory_start > 0:
    count_balance(lines, engineer_start, memory_start, "Engineer -> Memory")
    
if memory_start > 0 and pulse_start > 0:
    count_balance(lines, memory_start, pulse_start, "Memory -> Pulse")

if pulse_start > 0 and devops_start > 0:
    count_balance(lines, pulse_start, devops_start, "Pulse -> DevOps")
    
if devops_start > 0 and noah_start > 0:
    count_balance(lines, devops_start, noah_start, "DevOps -> Noah")

if noah_start > 0 and footer_start > 0:
    count_balance(lines, noah_start, footer_start, "Noah -> Footer")

