#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""检查所有模块的margin和height配置"""

import re

with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

modules = [
    ('page-container', '项目透视'),
    ('pending-features-module', '待开发任务'),
    ('architect-module', '架构师'),
    ('engineer-module', '全栈工程师'),
    ('memory-space-module', '记忆空间'),
    ('pulse-module', '实时脉动'),
    ('devops-module', '运维工程师'),
    ('code-manager-module', 'Noah代码管家')
]

print("=" * 90)
print("所有模块的 margin 和 height 配置检查")
print("=" * 90)
print()

print(f"{'模块':<20} {'max-width':<15} {'margin':<30} {'height':<20} {'状态'}")
print("-" * 90)

for class_name, display_name in modules:
    # 查找CSS定义
    pattern = rf'\.{class_name}\s*\{{([^}}]+)\}}'
    match = re.search(pattern, content, re.DOTALL)
    
    if not match:
        print(f"{display_name:<20} {'未找到CSS':<15} {'':<30} {'':<20} {'❌'}")
        continue
    
    css_block = match.group(1)
    
    # 提取关键属性
    max_width = re.search(r'max-width:\s*([^;]+)', css_block)
    margin = re.search(r'margin:\s*([^;]+)', css_block)
    height = re.search(r'height:\s*([^;]+)', css_block)
    
    max_width_val = max_width.group(1).strip() if max_width else "❌ 未设置"
    margin_val = margin.group(1).strip() if margin else "❌ 未设置"
    height_val = height.group(1).strip() if height else "无"
    
    # 判断是否正确
    is_correct = True
    issues = []
    
    if '1600px' not in max_width_val:
        is_correct = False
        issues.append("宽度错误")
    
    if '64px auto 48px auto' not in margin_val:
        is_correct = False
        issues.append("margin错误")
    
    if 'calc(100vh' in height_val:
        is_correct = False  
        issues.append("height用calc")
    
    status = "✅ OK" if is_correct else f"❌ {','.join(issues)}"
    
    print(f"{display_name:<20} {max_width_val:<15} {margin_val:<30} {height_val:<20} {status}")

print()
print("=" * 90)
print("关键检查项:")
print("  1. max-width 应该是 1600px")
print("  2. margin 应该是 64px auto 48px auto")
print("  3. height 不应该用 calc(100vh - 80px)，应该用固定值或不设置")
print("=" * 90)

