#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dashboard CSS状态诊断工具
快速检查所有模块的margin配置是否正确
"""

import re
import sys
from pathlib import Path

def check_module_css(file_path):
    """检查模块CSS配置"""
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 要检查的模块列表
    modules = [
        ('page-container', '项目透视塔'),
        ('pending-features-module', '待开发任务池'),
        ('architect-module', '架构师工作台'),
        ('engineer-module', '全栈工程师工作台'),
        ('devops-module', '运维工程师工作台'),
        ('code-manager-module', 'Noah代码管家'),
        ('memory-space-module', '项目记忆空间'),
        ('pulse-module', '实时脉动系统'),
    ]
    
    print("=" * 80)
    print("📋 Dashboard模块CSS诊断报告")
    print("=" * 80)
    print()
    
    all_correct = True
    
    for module_class, module_name in modules:
        # 查找模块CSS定义
        pattern = rf'\.{module_class}\s*\{{([^}}]+)\}}'
        match = re.search(pattern, content, re.DOTALL)
        
        if not match:
            print(f"❌ {module_name} ({module_class})")
            print(f"   找不到CSS定义")
            print()
            all_correct = False
            continue
        
        css_block = match.group(1)
        
        # 检查关键属性
        has_max_width = 'max-width:' in css_block or 'max-width :' in css_block
        has_margin_64 = '64px auto 48px auto' in css_block
        has_margin_auto = 'margin: 64px auto 48px auto' in css_block or 'margin:64px auto 48px auto' in css_block
        has_margin_bottom_only = bool(re.search(r'margin-bottom:\s*var\(--space-7\)', css_block)) and not has_margin_auto
        
        # 提取关键属性
        max_width_match = re.search(r'max-width:\s*([^;]+)', css_block)
        margin_match = re.search(r'margin:\s*([^;]+)', css_block)
        margin_bottom_match = re.search(r'margin-bottom:\s*([^;]+)', css_block)
        
        max_width_value = max_width_match.group(1).strip() if max_width_match else "❌ 未设置"
        margin_value = margin_match.group(1).strip() if margin_match else "❌ 未设置"
        
        # 判断状态
        if has_max_width and has_margin_64:
            status = "✅ 正确"
            status_icon = "✅"
        elif has_margin_bottom_only:
            status = "⚠️  只有下边距（旧版）"
            status_icon = "⚠️ "
            all_correct = False
        else:
            status = "❌ 配置错误"
            status_icon = "❌"
            all_correct = False
        
        print(f"{status_icon} {module_name} ({module_class})")
        print(f"   max-width: {max_width_value}")
        print(f"   margin: {margin_value}")
        print(f"   状态: {status}")
        print()
    
    # 检查body背景
    print("-" * 80)
    body_pattern = r'body\s*\{([^}]+)\}'
    body_match = re.search(body_pattern, content)
    if body_match:
        body_css = body_match.group(1)
        if 'var(--blanc-pearl)' in body_css or '#F6F8FA' in body_css:
            print("✅ body背景色: var(--blanc-pearl) (灰色) - 正确")
        else:
            print("❌ body背景色: 未设置或错误")
            all_correct = False
    else:
        print("❌ 找不到body CSS定义")
        all_correct = False
    
    # 检查main-container
    main_pattern = r'\.main-container\s*\{([^}]+)\}'
    main_match = re.search(main_pattern, content)
    if main_match:
        main_css = main_match.group(1)
        if 'background:' in main_css or 'background :' in main_css:
            print("⚠️  .main-container: 有background属性，可能遮挡灰色背景")
            all_correct = False
        else:
            print("✅ .main-container: 没有background属性 - 正确")
    
    print()
    print("=" * 80)
    
    if all_correct:
        print("🎉 所有CSS配置正确！")
        print()
        print("如果页面显示不正确，请尝试：")
        print("1. 强制刷新浏览器 (Ctrl + Shift + R)")
        print("2. 清除浏览器缓存")
        print("3. 确认访问 http://localhost:8820/ 而不是本地文件")
        return 0
    else:
        print("⚠️  发现CSS配置问题，需要修复")
        return 1

if __name__ == '__main__':
    file_path = Path(__file__).parent / 'index.html'
    
    if not file_path.exists():
        print(f"❌ 找不到文件: {file_path}")
        sys.exit(1)
    
    exit_code = check_module_css(file_path)
    sys.exit(exit_code)

