#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
检查所有模块的CSS margin配置
"""

import re
import sys

# 设置输出编码
sys.stdout.reconfigure(encoding='utf-8')

# 读取HTML文件
with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 定义模块信息
modules = [
    {'name': '项目透视塔', 'css_class': 'page-container', 'html_class': 'page-container'},
    {'name': '待开发任务池', 'css_class': 'pending-features-module', 'html_class': 'pending-features-module'},
    {'name': '架构师工作台', 'css_class': 'architect-module', 'html_class': 'architect-module'},
    {'name': '全栈工程师', 'css_class': 'engineer-module', 'html_class': 'engineer-module'},
    {'name': '记忆空间', 'css_class': 'memory-space-module', 'html_class': 'memory-space-module'},
    {'name': '实时脉动', 'css_class': 'pulse-module', 'html_class': 'pulse-module'},
    {'name': '运维工程师', 'css_class': 'devops-engineer-module', 'html_class': 'devops-engineer-module'},
    {'name': 'Noah代码管家', 'css_class': 'noah-code-butler-module', 'html_class': 'noah-code-butler-module'},
]

print("=" * 80)
print("Dashboard Module CSS Margin Check")
print("=" * 80)

for module in modules:
    print(f"\nModule: {module['name']}")
    print(f"  CSS class: .{module['css_class']}")
    
    # 1. 检查CSS定义
    css_pattern = rf'\.{re.escape(module["css_class"])}\s*\{{[^}}]*?margin:[^;]+;[^}}]*?\}}'
    css_match = re.search(css_pattern, content, re.DOTALL)
    
    if css_match:
        css_block = css_match.group(0)
        margin_match = re.search(r'margin:\s*([^;]+);', css_block)
        if margin_match:
            margin_value = margin_match.group(1).strip()
            print(f"  [OK] CSS margin: {margin_value}")
            
            # 检查是否有正确的margin值
            if '64px auto' in margin_value or '64px' in margin_value:
                print(f"  [OK] Margin value is correct")
            else:
                print(f"  [ERROR] Incorrect margin: {margin_value}")
        else:
            print(f"  [ERROR] No margin in CSS block")
    else:
        print(f"  [ERROR] CSS definition not found")
    
    # 2. 检查HTML使用
    html_pattern = rf'class="[^"]*{re.escape(module["html_class"])}[^"]*"'
    html_matches = re.findall(html_pattern, content)
    
    if html_matches:
        print(f"  [OK] Used in HTML: {len(html_matches)} time(s)")
        print(f"      Example: {html_matches[0]}")
    else:
        print(f"  [ERROR] Not used in HTML")

print("\n" + "=" * 80)
print("Check completed")
print("=" * 80)
