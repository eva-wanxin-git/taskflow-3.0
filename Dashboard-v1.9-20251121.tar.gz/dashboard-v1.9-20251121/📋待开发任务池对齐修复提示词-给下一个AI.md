# 📋 待开发任务池标头对齐修复提示词

**任务**: 修复Dashboard中"待开发任务池"模块的标头对齐问题  
**文件**: `dashboard-test/index.html`  
**问题**: 统计数字（8/2/4）垂直对齐不正确，数字应该顶部对齐，不是居中对齐

---

## 🎯 问题诊断

### 当前错误的对齐效果
```
┌─────────────────────────────────────────┐
│ 待开发任务池                            │  ← 第一行（正确）
├─────────────────────────────────────────┤
│                                         │
│ [PT] Pending Tasks Manager        8     │  ← 数字偏下了（错误）
│      任务管理·时间·同步        总任务    │
│                                 2     4  │
│                              待审核 进行中│
└─────────────────────────────────────────┘
```

### 正确的对齐效果（目标）
```
┌─────────────────────────────────────────┐
│ 待开发任务池                            │  ← 第一行
├─────────────────────────────────────────┤
│ [PT] Pending Tasks Manager    8   2   4 │  ← 数字顶部和标题对齐
│      任务管理·时间·同步       总  待  进 │
│                              任  审  行  │
│                              务  核  中  │
└─────────────────────────────────────────┘
```

**关键**: 数字"8"的顶部应该与"Pending Tasks Manager"文字的顶部齐平！

---

## 📂 文件位置

- **文件**: `C:\Users\Administrator\Desktop\taskflow-v1.7-from-github\dashboard-test\index.html`
- **端口**: `http://localhost:8820`
- **CSS位置**: 约1838行开始
- **HTML位置**: 约5752行开始

---

## 🔧 完整的CSS修复代码

请找到以下CSS部分并**完全替换**为新代码：

### 1. 标头容器（约1838行）

**查找这段代码**：
```css
/* 第1层：身份信息卡片 */
.pending-features-module .header-identity {
    padding: 24px 40px;
    display: flex;
    align-items: center;  /* ← 错误：这里是center */
    ...
}
```

**替换为**：
```css
/* 第1层：身份信息卡片 */
.pending-features-module .header-identity {
    padding: 24px 40px;
    display: flex;
    align-items: flex-start;  /* ← 关键修改！改为顶部对齐 */
    justify-content: space-between;
    gap: 40px;
    border-bottom: 1px solid var(--blanc-mist);
}
```

### 2. 左侧容器（约1848行）

**查找这段代码**：
```css
.pending-features-module .identity-left {
    display: flex;
    align-items: center;
    gap: 20px;
    flex: 1;  /* ← 可能有或没有这行 */
}
```

**替换为**：
```css
.pending-features-module .identity-left {
    display: flex;
    align-items: center;  /* 保持center，让头像和文字垂直居中 */
    gap: 20px;
}
```

### 3. 头像样式（约1854行）

**确保有这段代码**：
```css
.pending-features-module .module-avatar {
    width: 64px;
    height: 64px;
    background: var(--noir-ink);
    color: var(--blanc-pure);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: var(--weight-semibold);
    flex-shrink: 0;
}
```

### 4. 标题样式（约1873行）

**查找并修改**：
```css
.pending-features-module .module-title {
    font-size: var(--text-lg);
    font-weight: var(--weight-semibold);
    color: var(--noir-ink);
    line-height: 1.2;  /* ← 添加这行 */
    margin: 0;  /* ← 添加这行 */
}
```

### 5. 右侧统计数据容器（约1900行）

**查找这段代码**：
```css
/* 右侧统计数据 */
.pending-features-module .identity-right {
    display: flex;
    gap: 32px;  /* ← 可能是32px或48px */
    padding-left: 32px;  /* ← 可能有这行 */
    border-left: 1px solid var(--blanc-mist);  /* ← 可能有这行 */
}
```

**替换为**（简洁版）：
```css
/* 右侧统计数据 */
.pending-features-module .identity-right {
    display: flex;
    gap: 48px;
}
```

### 6. 统计项样式（约1907行）

**查找这段代码**：
```css
.pending-features-module .stat-item {
    text-align: center;  /* ← 或者是display: flex */
}
```

**替换为**：
```css
.pending-features-module .stat-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;  /* 数字和标签之间6px */
}
```

### 7. 统计数值样式（约1914行）

**查找这段代码**：
```css
.pending-features-module .stat-value {
    font-size: 28px;  /* 或 var(--text-xl) */
    font-weight: var(--weight-light);
    color: var(--noir-ink);
    margin-bottom: 4px;  /* ← 可能有这行 */
}
```

**替换为**：
```css
.pending-features-module .stat-value {
    font-size: 28px;
    font-weight: var(--weight-light);
    color: var(--noir-ink);
    line-height: 1;  /* ← 关键！消除额外空间 */
    letter-spacing: -0.02em;
}
```

### 8. 统计标签样式（约1922行）

**查找这段代码**：
```css
.pending-features-module .stat-label {
    font-size: var(--text-xs);
    color: var(--noir-silver);
    font-weight: var(--weight-regular);
}
```

**替换为**：
```css
.pending-features-module .stat-label {
    font-size: var(--text-xs);
    color: var(--noir-silver);
    font-weight: var(--weight-regular);
    line-height: 1;  /* ← 添加：消除额外空间 */
    white-space: nowrap;  /* ← 添加：防止换行 */
}
```

---

## 🎨 关键修改点总结

| CSS属性 | 位置 | 旧值 | 新值 | 原因 |
|--------|------|------|------|------|
| `.header-identity` `align-items` | ~1843行 | `center` | **`flex-start`** | 让所有子元素顶部对齐 |
| `.identity-left` `flex` | ~1852行 | `flex: 1` | **删除此行** | 不需要占据剩余空间 |
| `.identity-right` `gap` | ~1903行 | `32px` | **`48px`** | 间距调整 |
| `.stat-item` 结构 | ~1907行 | `text-align: center` | **`display: flex` + `flex-direction: column`** | 精确控制间距 |
| `.stat-value` `line-height` | ~1915行 | 缺失 | **`1`** | 消除额外空间 |
| `.stat-label` `line-height` | ~1923行 | 缺失 | **`1`** | 消除额外空间 |
| `.module-title` `line-height` | ~1874行 | 缺失 | **`1.2`** | 标题行高 |

---

## 📝 完整的目标CSS代码（可直接复制）

如果上面的修改太复杂，直接用这段完整的CSS替换整个标头部分：

```css
/* ==================== 待开发任务池标头 ==================== */

/* 标头容器 */
.pending-features-module .module-header {
    display: flex;
    flex-direction: column;
    background: var(--blanc-pure);
}

/* 第0层：模块分类标题 */
.pending-features-module .module-category {
    padding: 24px 40px 20px 40px;
    border-bottom: 1px solid var(--blanc-mist);
    width: 100%;
}

.pending-features-module .category-title {
    font-family: var(--font-secondary);
    font-size: var(--text-2xl);
    font-weight: var(--weight-light);
    color: var(--noir-ink);
    letter-spacing: -0.02em;
}

/* 第1层：身份信息卡片 */
.pending-features-module .header-identity {
    padding: 24px 40px;
    display: flex;
    align-items: flex-start;  /* ← 关键！顶部对齐 */
    justify-content: space-between;
    gap: 40px;
    border-bottom: 1px solid var(--blanc-mist);
}

/* 左侧：头像+信息 */
.pending-features-module .identity-left {
    display: flex;
    align-items: center;  /* 头像和文字垂直居中 */
    gap: 20px;
}

.pending-features-module .module-avatar {
    width: 64px;
    height: 64px;
    background: var(--noir-ink);
    color: var(--blanc-pure);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: var(--weight-semibold);
    flex-shrink: 0;
}

.pending-features-module .module-info {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.pending-features-module .module-title {
    font-size: var(--text-lg);
    font-weight: var(--weight-semibold);
    color: var(--noir-ink);
    line-height: 1.2;
    margin: 0;
}

.pending-features-module .module-meta {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: var(--text-sm);
    color: var(--noir-silver);
}

.pending-features-module .meta-separator {
    color: var(--blanc-cloud);
}

.pending-features-module .sync-indicator {
    width: 6px;
    height: 6px;
    background: var(--status-success);
    border-radius: 50%;
    animation: pulse-green 2s ease-in-out infinite;
}

/* 右侧：统计数据 */
.pending-features-module .identity-right {
    display: flex;
    gap: 48px;
}

.pending-features-module .stat-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
}

.pending-features-module .stat-value {
    font-size: 28px;
    font-weight: var(--weight-light);
    color: var(--noir-ink);
    line-height: 1;  /* ← 关键！ */
    letter-spacing: -0.02em;
}

.pending-features-module .stat-label {
    font-size: var(--text-xs);
    color: var(--noir-silver);
    font-weight: var(--weight-regular);
    line-height: 1;  /* ← 关键！ */
    white-space: nowrap;
}

.pending-features-module .stat-item.highlight .stat-value {
    color: var(--status-error);
}
```

---

## ✅ 验证方法

修改完成后，请按以下步骤验证：

### 1. 刷新浏览器
```
Ctrl + Shift + R（强制刷新，清除缓存）
```

### 2. 视觉检查
打开浏览器开发者工具（F12），检查：

```
✓ "Pending Tasks Manager" 和 数字"8" 的顶部应该对齐
✓ 数字和标签之间的间距应该是6px
✓ 三个统计项（8、2、4）的间距相等（48px）
✓ 头像（PT）和文字（Pending Tasks Manager）垂直居中
```

### 3. 浏览器开发者工具检查

右键点击数字"8" → 检查元素，查看：

```css
.header-identity {
    align-items: flex-start;  /* ← 应该是这个 */
}

.stat-value {
    line-height: 1;  /* ← 应该是这个 */
}
```

### 4. 对比参考

在同一页面找到"全栈工程师工作台"模块，对比对齐效果。两者应该类似（但待开发任务池多一行标题）。

---

## 🚨 常见错误

### 错误1: 改了CSS但没有生效
**原因**: 浏览器缓存  
**解决**: `Ctrl + Shift + R` 强制刷新，或者换端口（8821）

### 错误2: 数字还是偏下
**原因**: `line-height` 没有设置为1  
**解决**: 检查 `.stat-value` 的 `line-height: 1;` 是否添加

### 错误3: 统计数据跑到左边了
**原因**: `identity-left` 有 `flex: 1`  
**解决**: 删除 `identity-left` 的 `flex: 1` 属性

### 错误4: 数字和标签间距太大或太小
**原因**: `stat-item` 的 `gap` 不对  
**解决**: 确保 `gap: 6px`

---

## 🎯 最简单的修复方法（如果上面都不行）

1. **备份文件**
```powershell
cd C:\Users\Administrator\Desktop\taskflow-v1.7-from-github\dashboard-test
Copy-Item index.html "index.html.backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
```

2. **找到这3个关键CSS属性**

在 `dashboard-test/index.html` 中搜索并修改：

```css
/* 搜索1: .pending-features-module .header-identity */
align-items: center;  ← 改为 align-items: flex-start;

/* 搜索2: .pending-features-module .stat-value */
添加这行 → line-height: 1;

/* 搜索3: .pending-features-module .stat-label */
添加这行 → line-height: 1;
```

3. **保存并刷新**

---

## 📞 如果还是不行

如果修改后还是不对，请提供：
1. 截图（显示当前效果）
2. 开发者工具中 `.header-identity` 的 Computed 样式截图
3. 开发者工具中 `.stat-value` 的 Computed 样式截图

我会根据实际情况给出更精确的修复方案。

---

**生成时间**: 2025-11-20 17:00  
**适用版本**: taskflow-v1.7-from-github  
**难度等级**: ⭐⭐⭐（中等）  
**预计修复时间**: 5-10分钟

🎯 **核心要点**: 把 `align-items: center` 改为 `align-items: flex-start`，然后给统计数字和标签都加上 `line-height: 1`！

